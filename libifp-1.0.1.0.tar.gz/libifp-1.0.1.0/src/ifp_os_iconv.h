
#ifndef IFP_OS_ICONV_H
#define IFP_OS_ICONV_H 1

extern int local_iconv(char const * i_type, char const * o_type,
	char * ob, int max_o, const char * ib, int max_i);

#endif // IFP_OS_ICONV_H
