/* 
 * IRiver ifp filesystem driver for Linux
 * Revision : $Id: main.c,v 1.1 2004/10/08 15:44:14 oakhamg Exp $
 *
 * Copyright (C) Geoff Oakham, 2004; <oakhamg@users.sourceforge.net>
 */

#include <linux/module.h>

static int __init init_libifp(void)
{
	printk("libifp: successfully initialized.\n");
	return 0;
}

static void __exit exit_libifp(void)
{
	printk("libifp: unloaded.\n");
}

module_init(init_libifp)
module_exit(exit_libifp)

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("iRiver iFP Manager library");
MODULE_AUTHOR("Geoff Oakham <oakhamg@users.sourceforge.net>");

