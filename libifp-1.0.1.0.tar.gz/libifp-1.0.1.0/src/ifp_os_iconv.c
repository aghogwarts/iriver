/*
 * userland + iconv specific functions
 *
 * Split iconv(3) related code for avoid conflict native iconv and GNU libiconv.
 */

#include <iconv.h>

#include "ifp.h"
#include "ifp_os.h"
#include "ifp_os_iconv.h"

int local_iconv(char const * i_type, char const * o_type,
	char * ob, int max_o, const char * ib, int max_i)
{
	int i=0, e=0;
	char * ibb = (char *)ib;
	char * obb = (char *)ob;
	size_t i_n = max_i;
	size_t o_n = max_o;
	iconv_t ICONV;
	size_t r;

	if (i_type == NULL) {
		ifp_err("itype is NULL");
		i = -EINVAL;
		goto err;
	}

	if (o_type == NULL) {
		ifp_err("otype is NULL");
		i = -EINVAL;
		goto err;
	}

	ICONV = iconv_open(o_type, i_type);
	if (ICONV == (iconv_t)-1) {
		i = -errno;
		if(i==-EINVAL) {
			ifp_err_i(i, "conversion not supported by system");
		} else {
			ifp_err_i(i, "couldn't open conversion handle");
		}
		goto err;
	}

	r = iconv(ICONV, &ibb, &i_n, &obb, &o_n);
	if (r == (size_t)-1) {
		i = -errno;
		ifp_err_i(i, "problem converting, i_n is %d, o_n is %d, r = %d", i_n, o_n, r);
		goto err2;
	}

err2:
	e = iconv_close(ICONV);
	if (e) {
		e = -errno;
		ifp_err_i(e, "couldn't close conversion");
		i = i?i:e;
	}
err:
	return i;
}

